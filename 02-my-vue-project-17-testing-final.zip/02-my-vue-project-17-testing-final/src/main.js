import { createApp } from 'vue'
import MyRootComponent from './components/MyRootComponent.vue'

createApp(MyRootComponent).mount('#app')
