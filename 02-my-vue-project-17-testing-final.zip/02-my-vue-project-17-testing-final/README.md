# Goals - add more unit tests to Login UI

## Compile, Run the project and inspect the page

Note - This project is a Frontend app and need a backend API to work (see next section about using a backend) 

Checkout this locally https://gitlab.com/sysdev-tutorials/vuejs/02-my-vue-project/-/tree/12-final

```
# download dependencies (one time operation or do it again when new libraries are added)
npm install 
# compile and hot-reload for development
npm run serve
# inspect page contents
```

## Run a backend demo API locally 

Locally checkout this repo: https://gitlab.com/sysdev-tutorials/springboot/auth_demo/-/tree/test.
Switch to 'test' branch. Then from the project folder, run

```
mvn spring-boot:run
```

Note the context path and port number given src/main/resources/application.properties file.
Correct port should be used from frontend part.

## Mock API call
In this session, we will MOCK the API call so that we can test API call utilitie without actually needing a real backend server running

Add a new file ```test/unit/apiutil-mock.spec.js``` with following content

```
import { doLogin } from '@/utils/apiutil'
import axios from 'axios';

jest.mock('axios')

describe('testing mocking of apiutil.vue', () => {
    it('check that login is successful - against mock', async () => {

        // mock api response on POST call (once)
        const expectedLoginRespone = { loginStatus: 'Success' };
        axios.post.mockImplementation(() => Promise.resolve({ data: expectedLoginRespone }));

        // do the call
        const loginRequest = { username:"user1", password: "pass1" };
        const loginResponse = await doLogin(loginRequest);  

        //  check response
        //  note that even if wrong username and password are used, mock is configured to return Success
        expect(loginResponse).toEqual(expectedLoginRespone);
    })
})
```

Now, inorder to test the above test case, one can stop the demo backend api/server. 

And, add this to the scripts section of ```package.json``` file.

```
    "test:unit-mockapi": "vue-cli-service test:unit tests/unit/apiutil-mock.spec.js",
```


Then run this command ```npm run test:unit-mockapi```. 